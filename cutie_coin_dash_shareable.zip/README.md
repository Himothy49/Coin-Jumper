# Cutie Coin Dash

Self-contained 5-level browser platformer.

The game entry point is `index.html`. Upload this folder to a static host
such as GitHub Pages, Netlify, or itch.io.
